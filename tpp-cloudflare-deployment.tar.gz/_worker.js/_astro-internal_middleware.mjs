globalThis.process ??= {}; globalThis.process.env ??= {};
import './chunks/astro-designed-error-pages_RrojTzxE.mjs';
import './chunks/astro/server_3w_IlUv4.mjs';
import { s as sequence } from './chunks/index_CLHiLsVO.mjs';

const onRequest$1 = (context, next) => {
  if (context.isPrerendered) {
    context.locals.runtime ??= {
      env: process.env
    };
  }
  return next();
};

const onRequest = sequence(
	onRequest$1,
	
	
);

export { onRequest };
