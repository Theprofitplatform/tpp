globalThis.process ??= {}; globalThis.process.env ??= {};
const renderers = [];

export { renderers };
